export class AllTasks {
    description: string;
    priority: string;
    status: number;
    date: string;
    numberOfPriority: number;
    descOfStatus: string;

    constructor(description: string, priority: string, status: number, date: string, numberOfPriority: number, descOfStatus: string) {
        this.description = description;
        this.priority = priority;
        this.status = status;
        this.date = date;
        this.numberOfPriority =  numberOfPriority;
        this.descOfStatus = descOfStatus;
    }
}