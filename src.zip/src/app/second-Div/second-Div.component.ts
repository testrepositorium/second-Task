import {Component} from '@angular/core';

@Component({
    selector: 'second-comp',
    templateUrl: './second-Div.component.html',
    styleUrls: ['./second-Div.component.css']
})

export class SecondComponent {
    
}