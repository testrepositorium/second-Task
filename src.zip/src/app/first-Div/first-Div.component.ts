import {Component} from '@angular/core';

import { AllTasks } from '../allTasks.model';
import { AllTasksService } from '../allTasks.service';

@Component({
    selector: 'first-comp',
    templateUrl: './first-Div.component.html',
    styleUrls: ['./first-Div.component.css']
})

export class FirstComponent {
    
}