import {Component} from '@angular/core';


@Component({
    selector: 'third-comp',
    templateUrl: './third-Div.component.html',
    styleUrls: ['./third-Div.component.css']
})

export class ThirdComponent {

    constructor() {
    }


}